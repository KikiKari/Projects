package app.tiktoklivecompanion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeEngine : RecognitionEngine {
    override var onResult: ((RecognitionResult) -> Unit)? = null
    override var onError: ((String) -> Unit)? = null
    var microphoneStarts = 0; var streamStarts = 0
    override fun recognizeMicrophone() { microphoneStarts++ }
    override fun startPcmStream(sampleRate: Int) { streamStarts++ }
    override fun appendPcm16(bytes: ByteArray, sampleRate: Int) {}
    override fun finishPcmStream() {}
    override fun cancel() {}
}

class CompanionViewModelTest {
    @Test fun customTriggersFilterOnlySelectedPrefixes() {
        for (enabled in listOf(false,true)) for (text in listOf(".Hallo",",Hallo","- Hallo","Hallo, zusammen.")) {
            val model=CompanionViewModel(FakeEngine())
            model.setExternalSpeechTriggerCharacters(".,-")
            model.setFilterExternalSpeechTriggers(enabled)
            model.requestSpeak(ChatLine("Autor",text))
            assertEquals(if (enabled && text != "Hallo, zusammen.") 0 else 1,model.state.value.speechQueue.size)
            model.setFilterExternalSpeechTriggers(!enabled)
            assertEquals(".,-",model.state.value.externalSpeechTriggerCharacters)
        }
        assertEquals(".,-;:",ExternalSpeechTriggers.normalize(".,-;:!"))
        assertEquals("😀😁😂😃😄",ExternalSpeechTriggers.normalize("😀😁😂😃😄😅"))
        assertEquals(".,-",ExternalSpeechTriggers.normalize(" a1 \"'.,- "))
        assertFalse(ExternalSpeechTriggers.matches(".Hallo",true,""))
        assertTrue(ExternalSpeechTriggers.matches(";Hallo",true,";"))
        assertTrue(ExternalSpeechTriggers.matches("[Hallo",true,"["))
    }
    @Test fun externalTriggerFilterIsIndependentOfGameModeAndNames() {
        for (game in listOf(false,true)) for (enabled in listOf(false,true)) {
            for (text in listOf(".Text", ". Text", "  .Text", "Normal", "Ein Satz. Noch einer")) {
                val model = CompanionViewModel(FakeEngine())
                model.setGameMode(game); model.setFilterExternalSpeechTriggers(enabled)
                model.requestSpeak(ChatLine("Autor", text))
                assertEquals(if (enabled && text.trimStart().startsWith(".")) 0 else 1, model.state.value.speechQueue.size)
            }
        }
    }

    @Test fun recognitionStartsOnlyAfterExplicitAction() {
        val engine = FakeEngine(); val model = CompanionViewModel(engine)
        assertEquals(0, engine.microphoneStarts)
        model.recognize(); assertEquals(1, engine.microphoneStarts)
        model.selectSource(RecognitionSource.WEBVIEW); model.recognize(); assertEquals(1, engine.streamStarts)
    }

    @Test fun speechDeduplicatesExactRepeats() {
        val model = CompanionViewModel(FakeEngine())
        assertTrue(model.spokenLineAllowed("Smoke One: Ja lecker", now = 1_000))
        assertFalse(model.spokenLineAllowed("Smoke One:  Ja lecker", now = 2_000))
        assertTrue(model.spokenLineAllowed("Smoke One: Ja lecker", now = 25_000))
    }

    @Test fun mobileControlsUpdateStateAndCommands() {
        val model = CompanionViewModel(FakeEngine())
        val commands = mutableListOf<Pair<String, Map<String, Any>>>()
        model.sendCommand = { command, payload -> commands += command to payload }
        model.setAutoReconnect(false)
        model.setLimiter(true, 90)
        assertFalse(model.state.value.autoReconnectEnabled)
        assertTrue(model.state.value.limiterEnabled)
        assertEquals(90, model.state.value.limiterStrength)
        assertEquals("set-auto-reconnect", commands.first().first)
        assertEquals("set-limiter", commands.last().first)
    }
}
