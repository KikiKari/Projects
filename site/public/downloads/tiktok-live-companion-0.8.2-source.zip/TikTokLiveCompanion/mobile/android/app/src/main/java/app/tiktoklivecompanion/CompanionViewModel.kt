package app.tiktoklivecompanion

import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

data class CompanionUiState(
    val serviceVoices: List<ServiceVoice> = emptyList(),
    val serviceStatus: String = "",
    val hookReconnectEnabled: Boolean = false,
    val hookReconnectDelaySeconds: Int = 3,
    val hookRecovery: Map<String, Any?> = emptyMap(),
    val playerRecovery: Map<String, Any?> = emptyMap(),
    val captionSources: Map<String, Any?> = emptyMap(),
    val embedMode: Boolean = false,
    val embedPhase: String = "idle",
    val embedAttempt: Int = 0,
    val tab: CompanionTab = CompanionTab.SONG,
    val source: RecognitionSource = RecognitionSource.MICROPHONE,
    val recognitionStatus: String = "Bereit für manuelle Erkennung",
    val result: RecognitionResult? = null,
    val connected: Boolean = false,
    val hookAvailable: Boolean = false,
    val connectionEnabled: Boolean = false,
    val autoChatRefreshEnabled: Boolean = false,
    val autoChatRefreshMinutes: Int = 5,
    val captionsAvailable: Boolean = false,
    val chats: List<String> = emptyList(),
    val chatEntries: List<ChatLine> = emptyList(),
    val liveValues: Map<String, String> = emptyMap(),
    val participants: Map<String, ParticipantStats> = emptyMap(),
    val liveNumbers: Map<String, Long> = emptyMap(),
    val pageInfo: Map<String, String> = emptyMap(),
    val mutedAuthors: Set<String> = emptySet(),
    val limiterEnabled: Boolean = false,
    val limiterThreshold: Int = -6,
    val limiterStrength: Int = 30,
    val webLimiterStatus: String = "WebView · Pegelschutz aus",
    val nativeLimiterStatus: String = "Noch keine native Audiomessung",
    val ttsEnabled: Boolean = false,
    val ttsVolume: Int = 100,
    val ttsLanguage: TtsLanguage = TtsLanguage.AUTO,
    val ttsSpeakNames: Boolean = true,
    val ttsShortenNames: Boolean = true,
    val speechQueue: List<SpeechRequest> = emptyList(),
    val error: String? = null,
    val videoExpanded: Boolean = false,
    val forceInProgress: Boolean = false,
    val forceRecoveryUrl: String? = null,
    val audibleStartRequested: Boolean = false,
    val playerMuted: Boolean? = null,
    val audibleStartBlocked: Boolean = false,
    val mediaUrls: List<StreamMediaUrl> = emptyList(),
    val vlcReplacementUrl: String? = null,
    val debugEnabled: Boolean = false,
    val debugEvents: List<String> = emptyList(),
    val streamName: String = "",
    val autoReconnectEnabled: Boolean = false,
    val autoReconnectDelaySeconds: Int = 3,
    val gameModeEnabled: Boolean = true,
    val filterExternalSpeechTriggers: Boolean = false,
    val externalSpeechTriggerCharacters: String = ".",
    val auddToken: String = "",
    val pairingCode: String = "",
    val universalCaptionApiKey: String = "",
    val ttsVoice: String = "Systemstandard",
    val liveLogsEnabled: Boolean = false,
    val captionRecords: List<CaptionRecord> = emptyList(),
    val recommendationStatus: String = "idle",
    val recommendationLimit: Int = 20,
    val recommendationScanned: Int = 0,
    val recommendationItems: List<RecommendationItem> = emptyList()
) {
    val topChatters: List<TopChatter>
        get() = participants.entries.sortedWith(compareByDescending<Map.Entry<String, ParticipantStats>> { it.value.messages }.thenByDescending { it.value.words }.thenBy { it.key.lowercase() }).map { TopChatter(it.key, it.value.messages, it.value.words) }
}

class CompanionViewModel(private val recognizer: RecognitionEngine, private val preferences: CompanionPreferences? = null) : ViewModel() {
    var serviceClient: CompanionServiceClient? = null
        set(value) {
            field = value
            pipelineRetryJob?.cancel()
            if (value != null) pipelineRetryJob = viewModelScope.launch {
                while (true) {
                    value.pairingCode = mutable.value.pairingCode
                    value.universalKey = mutable.value.universalCaptionApiKey
                    value.auddToken = mutable.value.auddToken
                    runCatching { value.flush() }.onFailure {
                        mutable.update { it.copy(serviceStatus = "Pipeline-Verbindung unterbrochen; gespeicherte Daten werden erneut gesendet.") }
                    }
                    delay(30_000)
                }
            }
        }
    private var pipelineRetryJob: Job? = null
    fun loadServiceVoices() { viewModelScope.launch {
        runCatching {
            val client = requireNotNull(serviceClient)
            client.pairingCode = mutable.value.pairingCode
            val data = JSONObject(String(client.request("/v1/voices"), Charsets.UTF_8))
            client.universalKey = mutable.value.universalCaptionApiKey
            client.auddToken = mutable.value.auddToken
            runCatching { client.publishData("sherpa", mapOf("catalog" to data)) }
            val health = JSONObject(String(client.request("/v1/health"), Charsets.UTF_8))
            runCatching { client.publishData("speech-service", mapOf("health" to health)) }
            val catalog = data.optJSONArray("catalog") ?: JSONArray()
            val voices = (0 until catalog.length()).map { i -> catalog.getJSONObject(i).let { voice -> ServiceVoice(voice.getString("id"), voice.getString("name"), voice.optString("culture"), voice.optBoolean("installed"), voice.optLong("bytes"), voice.optJSONObject("license")?.optString("id") ?: "", voice.optString("group")) } }
            mutable.update { it.copy(serviceVoices = voices, serviceStatus = "Companion-Dienst verbunden") }
        }.onFailure { error -> mutable.update { it.copy(serviceStatus = error.message ?: "Companion-Dienst nicht erreichbar") } }
    } }
    fun installServiceVoice(id: String) { viewModelScope.launch {
        runCatching {
            val client = requireNotNull(serviceClient)
            client.pairingCode = mutable.value.pairingCode
            client.request("/v1/voices/install", JSONObject().put("voiceId", id))
            mutable.update { it.copy(serviceStatus = "Stimme wird installiert") }
            for (attempt in 0 until 120) {
                delay(2000)
                val status = JSONObject(String(client.request("/v1/sherpa/status"), Charsets.UTF_8))
                if (!status.optBoolean("running")) {
                    check(status.optString("error", "").let { it.isBlank() || it == "null" }) { status.optString("error") }
                    loadServiceVoices(); return@launch
                }
            }
            error("Installation dauert länger; Status erneut laden")
        }.onFailure { error -> mutable.update { it.copy(serviceStatus = error.message ?: "Stimme konnte nicht installiert werden") } }
    } }
    private val mutable = MutableStateFlow(CompanionUiState())
    val state: StateFlow<CompanionUiState> = mutable
    var sendCommand: ((String, Map<String, Any>) -> Unit)? = null
    var loadUrl: ((String) -> Unit)? = null
    var reloadPage: (() -> Unit)? = null
    var backgroundPlaybackChanged: ((Boolean) -> Unit)? = null
    var currentWebUrl: String = "https://www.tiktok.com/live"
        private set
    private var connectionPaused = false
    private var connectionRequested = true
    private var bridgeReady = false
    private var hookReconnectRequested = false
    private var playerRecoveryRequested = false
    private var nativePlayerStalledAt = 0L
    private var nativePlayerTime: Double? = null
    private var nativePlayerDocument: String? = null
    private var nativePlayerAttempt = 0
    private var startupLimiterPending = false
    private var currentDocument: String? = null
    private val retiredDocuments = mutableSetOf<String>()
    private var embedJob: Job? = null
    private var embedStartedAt = 0L
    private var embedId = ""
    private var captionExpiry: Job? = null
    private var chatRefreshJob: Job? = null
    private var speechSequence = 0L
    private var forceWatchdog: Job? = null
    private val recentSpeech = LinkedHashMap<String, Long>()
    private val repeatWindowMs = 20_000L

    private companion object {
        val liveStatLabels = mapOf(
            "viewerCount" to "Zuschauer*innen",
            "totalViewers" to "Aufrufe gesamt",
            "likeCount" to "Likes",
            "followerCount" to "Follower gesamt",
            "shareCount" to "Teilungen"
        )
    }

    init {
        recognizer.onResult = { result ->
            mutable.update { it.copy(result = result, recognitionStatus = if (result.matched) "Song erkannt" else "Kein passender Song erkannt") }
            serviceClient?.let { client ->
                client.pairingCode = mutable.value.pairingCode; client.universalKey = mutable.value.universalCaptionApiKey
            client.auddToken = mutable.value.auddToken
                viewModelScope.launch { runCatching { client.publishData("songs", mapOf("matched" to result.matched, "title" to result.title, "artist" to result.artist, "album" to result.album, "artworkUrl" to result.artworkUrl, "songUrl" to result.songUrl, "matchOffset" to result.matchOffset, "source" to result.source.name)) } }
            }
        }
        recognizer.onError = { message -> mutable.update { it.copy(error = message, recognitionStatus = message) } }
        preferences?.let { stored ->
            viewModelScope.launch { stored.autoChatRefreshEnabled.collectLatest { value -> mutable.update { it.copy(autoChatRefreshEnabled = value) }; scheduleChatRefresh() } }
            viewModelScope.launch { stored.autoChatRefreshMinutes.collectLatest { value -> mutable.update { it.copy(autoChatRefreshMinutes = value) }; scheduleChatRefresh() } }
            viewModelScope.launch { stored.source.collectLatest { source -> mutable.update { it.copy(source = source) } } }
            viewModelScope.launch { stored.mutedAuthors.collectLatest { authors -> mutable.update { it.copy(mutedAuthors = authors) } } }
            viewModelScope.launch { stored.limiterEnabled.collectLatest { enabled -> mutable.update { it.copy(limiterEnabled = enabled) } } }
            viewModelScope.launch { stored.limiterThreshold.collectLatest { threshold -> mutable.update { it.copy(limiterThreshold = threshold) } } }
            viewModelScope.launch { stored.limiterStrength.collectLatest { strength -> mutable.update { it.copy(limiterStrength = strength) } } }
            viewModelScope.launch { stored.ttsEnabled.collectLatest { value -> mutable.update { it.copy(ttsEnabled = value) } } }
            viewModelScope.launch { stored.ttsVolume.collectLatest { value -> mutable.update { it.copy(ttsVolume = value) } } }
            viewModelScope.launch { stored.ttsLanguage.collectLatest { value -> mutable.update { it.copy(ttsLanguage = value) } } }
            viewModelScope.launch { stored.ttsSpeakNames.collectLatest { value -> mutable.update { it.copy(ttsSpeakNames = value) } } }
            viewModelScope.launch { stored.ttsShortenNames.collectLatest { value -> mutable.update { it.copy(ttsShortenNames = value) } } }
            viewModelScope.launch { stored.autoReconnect.collectLatest { value -> playerRecoveryRequested = value; pushRecovery() } }
            viewModelScope.launch { stored.autoReconnectDelay.collectLatest { value -> mutable.update { it.copy(autoReconnectDelaySeconds = value) }; pushRecovery() } }
            viewModelScope.launch { stored.hookEnabled.collectLatest { value -> hookReconnectRequested = value; pushRecovery() } }
            viewModelScope.launch { stored.hookDelay.collectLatest { value -> mutable.update { it.copy(hookReconnectDelaySeconds = value) }; pushRecovery() } }
            viewModelScope.launch { stored.auddToken.collectLatest { value -> mutable.update { it.copy(auddToken = value) } } }
            viewModelScope.launch { stored.pairingCode.collectLatest { value -> mutable.update { it.copy(pairingCode = value) } } }
            viewModelScope.launch { stored.universalCaptionApiKey.collectLatest { value -> mutable.update { it.copy(universalCaptionApiKey = value) } } }
            viewModelScope.launch { stored.filterExternalSpeechTriggers.collectLatest { value -> mutable.update { it.copy(filterExternalSpeechTriggers = value) } } }
            viewModelScope.launch { stored.externalSpeechTriggerCharacters.collectLatest { value -> mutable.update { it.copy(externalSpeechTriggerCharacters = value) } } }
            viewModelScope.launch { stored.gameMode.collectLatest { value -> mutable.update { it.copy(gameModeEnabled = value) } } }
            viewModelScope.launch { stored.ttsVoice.collectLatest { value -> mutable.update { it.copy(ttsVoice = value) } } }
        }
    }

    fun selectTab(tab: CompanionTab) = mutable.update { it.copy(tab = tab) }
    fun selectSource(source: RecognitionSource) {
        mutable.update { it.copy(source = source) }
        preferences?.let { stored -> viewModelScope.launch { stored.setSource(source) } }
    }
    fun clearError() = mutable.update { it.copy(error = null) }
    fun setDebugEnabled(enabled: Boolean) = mutable.update { it.copy(debugEnabled = enabled) }
    fun clearDebugEvents() = mutable.update { it.copy(debugEvents = emptyList()) }
    fun debugReport(vlcInstalled: Boolean): String {
        val current = mutable.value
        return JSONObject(mapOf(
            "generatedAtUtc" to java.time.Instant.now().toString(),
            "version" to "0.8.2",
            "platform" to "android",
            "components" to mapOf(
                "layout" to mapOf("liveInformationBeforePageInformation" to true),
                "vlcReplacement" to mapOf("placement" to "main-video-frame", "installed" to vlcInstalled, "active" to (current.vlcReplacementUrl != null), "candidateCount" to current.mediaUrls.size),
                "speechAndChatSettings" to mapOf("settingsDialogAvailable" to true, "auddTokenConfigured" to current.auddToken.isNotBlank(), "pairingConfigured" to current.pairingCode.isNotBlank(), "universalCaptionApiKeyConfigured" to current.universalCaptionApiKey.isNotBlank(), "speakNames" to current.ttsSpeakNames, "shortenNames" to current.ttsShortenNames, "gameModeEnabled" to current.gameModeEnabled, "language" to current.ttsLanguage.name, "voiceConfigured" to current.ttsVoice.isNotBlank()),
                "captions" to mapOf("rawBridgeStreamCaptured" to false, "available" to current.captionsAvailable, "eventCount" to current.captionRecords.size, "jsonLinesExportAvailable" to true, "rawJsonExportAvailable" to true),
                "songRecognition" to mapOf("path" to "android-native-audd-microphone-or-webview", "source" to current.source.label),
                "topChatters" to mapOf("observedCount" to current.participants.size, "mutedCount" to current.mutedAuthors.size, "resetAvailable" to true),
                "recommendations" to mapOf("available" to true, "status" to current.recommendationStatus, "requested" to current.recommendationLimit, "scanned" to current.recommendationScanned, "found" to current.recommendationItems.size),
                "hookReconnect" to mapOf("enabled" to current.hookReconnectEnabled, "delaySeconds" to current.hookReconnectDelaySeconds),
                "autoReconnect" to mapOf("enabled" to current.autoReconnectEnabled, "delaySeconds" to current.autoReconnectDelaySeconds)
            ),
            "schemaVersion" to "tiktok-live-companion-diagnostic-v3",
            "snapshotId" to java.util.UUID.randomUUID().toString(),
            "hookRecovery" to JSONObject(RecoveryDiagnostics.hook(current.hookRecovery)),
            "playerRecovery" to JSONObject(RecoveryDiagnostics.project(current.playerRecovery)),
            "captionSources" to JSONObject(RecoveryDiagnostics.project(current.captionSources)),
            "embedStartup" to mapOf("id" to embedId, "phase" to current.embedPhase, "attempt" to current.embedAttempt),
            "bridgeEvents" to JSONArray(current.debugEvents.map { JSONObject(it) })
        )).toString(2)
    }
    fun setFilterExternalSpeechTriggers(enabled: Boolean) { mutable.update { it.copy(filterExternalSpeechTriggers = enabled) }; preferences?.let { stored -> viewModelScope.launch { stored.setFilterExternalSpeechTriggers(enabled) } } }
    fun setExternalSpeechTriggerCharacters(value: String) { val safe = ExternalSpeechTriggers.normalize(value); mutable.update { it.copy(externalSpeechTriggerCharacters = safe) }; preferences?.let { stored -> viewModelScope.launch { stored.setExternalSpeechTriggerCharacters(safe) } } }
    fun clearChat() = mutable.update { it.copy(chats = emptyList(), chatEntries = emptyList()) }

    private fun scheduleChatRefresh() {
        chatRefreshJob?.cancel()
        if (!mutable.value.autoChatRefreshEnabled) return
        chatRefreshJob = viewModelScope.launch {
            while (true) {
                delay(mutable.value.autoChatRefreshMinutes * 60_000L)
                clearChat()
            }
        }
    }
    fun setAutoChatRefreshEnabled(enabled: Boolean) {
        mutable.update { it.copy(autoChatRefreshEnabled = enabled) }; scheduleChatRefresh()
        preferences?.let { stored -> viewModelScope.launch { stored.setAutoChatRefreshEnabled(enabled) } }
    }
    fun setAutoChatRefreshMinutes(minutes: Int) {
        val safe = minutes.coerceIn(1, 60)
        mutable.update { it.copy(autoChatRefreshMinutes = safe) }; scheduleChatRefresh()
        preferences?.let { stored -> viewModelScope.launch { stored.setAutoChatRefreshMinutes(safe) } }
    }
    fun setConnectionEnabled(enabled: Boolean) {
        connectionRequested = enabled
        if (enabled) {
            // Capture the site's new sockets from document start, as in the browser extension.
            resetPage()
            return
        }
        val dispatch = sendCommand ?: return reportError("Connection ist noch nicht bereit")
        dispatch("set-connection", mapOf("enabled" to enabled))
    }
    fun resetPage() = reloadWebPage(enableConnection = true)
    private fun reloadWebPage(enableConnection: Boolean) {
        val reload = reloadPage ?: return reportError("Browser ist noch nicht bereit")
        if (enableConnection) connectionRequested = true
        backgroundPlaybackChanged?.invoke(true)
        reload()
    }
    fun setGameMode(enabled: Boolean) { mutable.update { it.copy(gameModeEnabled = enabled) }; preferences?.let { stored -> viewModelScope.launch { stored.setGameMode(enabled) } } }
    fun setAuddToken(value: String) { val safe = value.take(4096); mutable.update { it.copy(auddToken = safe) }; preferences?.let { stored -> viewModelScope.launch { stored.setAuddToken(safe) } } }
    fun setPairingCode(value: String) { val safe = value.take(512); mutable.update { it.copy(pairingCode = safe) }; preferences?.let { stored -> viewModelScope.launch { stored.setPairingCode(safe) } } }
    fun setUniversalCaptionApiKey(value: String) { val safe = value.take(4096); mutable.update { it.copy(universalCaptionApiKey = safe) }; sendCommand?.invoke("set-pipeline-enabled", mapOf("enabled" to safe.isNotBlank())); preferences?.let { stored -> viewModelScope.launch { stored.setUniversalCaptionApiKey(safe) } } }
    fun setTtsVoice(value: String) { val safe = value.take(160); mutable.update { it.copy(ttsVoice = safe) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsVoice(safe) } } }
    fun resetTopChatters() = mutable.update { it.copy(participants = emptyMap()) }
    fun toggleVideoExpanded() {
        val expanded = !mutable.value.videoExpanded
        mutable.update { it.copy(videoExpanded = expanded) }
        sendCommand?.invoke("set-player-expanded", mapOf("expanded" to expanded))
    }
    fun toggleVlcReplacement() {
        val next = if (mutable.value.vlcReplacementUrl != null) null else bestMediaUrl(mutable.value.mediaUrls)?.url
        if (next == null && mutable.value.vlcReplacementUrl == null) { reportError("Keine Media-URL verfügbar"); return }
        mutable.update { it.copy(vlcReplacementUrl = next, videoExpanded = false) }
        sendCommand?.invoke("set-vlc-active", mapOf("active" to (next != null)))
    }
    fun bestVlcMediaUrl(): String? = bestMediaUrl(mutable.value.mediaUrls)?.url
    fun expandVideo() {
        if (mutable.value.videoExpanded) return
        mutable.update { it.copy(videoExpanded = true) }
        sendCommand?.invoke("set-player-expanded", mapOf("expanded" to true))
    }
    fun setStreamName(name: String) = mutable.update { it.copy(streamName = name) }
    fun startForce() {
        val recovery = mutable.value.pageInfo["URL"]?.takeIf { it.matches(Regex("https://www\\.tiktok\\.com/@[^/]+/live(?:[/?#].*)?")) }
            ?: StreamNameNormalizer.liveUrl(mutable.value.streamName)
        if (recovery == null) { reportError("Force ist erst in einem gültigen LIVE-Stream verfügbar"); return }
        forceWatchdog?.cancel()
        mutable.update { it.copy(forceInProgress = true, forceRecoveryUrl = recovery, error = null) }
        sendCommand?.invoke("force-profile", mapOf("liveUrl" to recovery))
        forceWatchdog = viewModelScope.launch {
            delay(20_000)
            if (mutable.value.forceInProgress) recoverForce("Timeout nach 20 Sekunden")
        }
    }
    fun recoverForce(reason: String = "manuelle Rückkehr") {
        val recovery = mutable.value.forceRecoveryUrl
        forceWatchdog?.cancel()
        mutable.update { it.copy(forceInProgress = false, error = if (recovery == null) "Force: $reason · bitte manuell zurück" else "Force: $reason · LIVE-Stream wurde wieder geöffnet") }
        recovery?.let { currentWebUrl = it; loadUrl?.invoke(it) }
    }
    fun noteNavigation(url: String) {
        nativePlayerStalledAt = 0L
        nativePlayerTime = null
        nativePlayerDocument = null
        bridgeReady = false
        startupLimiterPending = false
        currentDocument?.let { retiredDocuments.add(it) }
        currentDocument = null
        captionExpiry?.cancel()
        mutable.update { it.copy(connected = false, connectionEnabled = false, hookAvailable = false, hookReconnectEnabled = false, autoReconnectEnabled = false, captionsAvailable = false, captionSources = emptyMap(), hookRecovery = emptyMap(), playerRecovery = emptyMap()) }
        if (url.matches(Regex("https://www\\.tiktok\\.com/@[^/]+/live(?:[/?#].*)?"))) currentWebUrl = url
    }
    fun openStream() {
        embedJob?.cancel(); mutable.update { it.copy(embedMode = false, embedPhase = "idle", embedAttempt = 0) }
        val url = StreamNameNormalizer.liveUrl(mutable.value.streamName)
        if (url == null) { reportError("Ungültiger Streamname · erlaubt sind Buchstaben, Ziffern, Punkt und Unterstrich"); return }
        mutable.update { it.copy(connected = false, hookAvailable = false, captionsAvailable = false, chats = emptyList(), chatEntries = emptyList(), speechQueue = emptyList(), liveValues = emptyMap(), liveNumbers = emptyMap(), participants = emptyMap(), pageInfo = emptyMap(), audibleStartRequested = true, playerMuted = null, audibleStartBlocked = false, mediaUrls = emptyList(), vlcReplacementUrl = null, captionRecords = emptyList(), recommendationStatus = "idle", recommendationScanned = 0, recommendationItems = emptyList()) }
        backgroundPlaybackChanged?.invoke(true)
        currentWebUrl = url
        loadUrl?.invoke(url)
    }
    fun enableStreamSound() {
        mutable.update { it.copy(audibleStartRequested = true, audibleStartBlocked = false) }
        sendCommand?.invoke("start-audible", emptyMap())
    }
    fun reportError(message: String) = mutable.update { it.copy(error = message, recognitionStatus = message) }
    fun muteAuthor(author: String) {
        val normalized = author.trim().take(80)
        if (normalized.isEmpty()) return
        val updated = mutable.value.mutedAuthors + normalized
        mutable.update { it.copy(mutedAuthors = updated, chats = it.chats.filterNot { line -> line.startsWith("$normalized:") }, chatEntries = it.chatEntries.filterNot { line -> line.author == normalized }, participants = it.participants - normalized) }
        preferences?.let { stored -> viewModelScope.launch { stored.setMutedAuthors(updated) } }
    }
    fun reportNativeLimiter(url: String, active: Boolean, input: Double, output: Double, reduction: Double, failure: String?) {
        mutable.update {
            if (it.vlcReplacementUrl != url) it else it.copy(
                nativeLimiterStatus = failure ?: String.format(java.util.Locale.ROOT,
                    "VLC intern · Schutz %s · Eingang %.1f dBFS · Ausgang %.1f dBFS · Dämpfung %.1f dB · Vorlauf 5 ms",
                    if (active) "aktiv" else "aus", input, output, reduction),
                limiterEnabled = if (failure != null) false else it.limiterEnabled,
                error = failure ?: it.error)
        }
    }
    fun setLimiterEnabled(enabled: Boolean) {
        mutable.update { it.copy(limiterEnabled = enabled) }
        preferences?.let { stored -> viewModelScope.launch { stored.setLimiterEnabled(enabled) } }
        pushLimiter()
    }
    fun setLimiterThreshold(threshold: Int) {
        val clamped = threshold.coerceIn(-30, -1)
        mutable.update { it.copy(limiterThreshold = clamped, limiterStrength = thresholdToStrength(clamped)) }
        preferences?.let { stored -> viewModelScope.launch { stored.setLimiterThreshold(clamped) } }
        pushLimiter()
    }
    fun setLimiter(enabled: Boolean, strength: Int = mutable.value.limiterStrength) {
        val safeStrength = strength.coerceIn(0, 100)
        val threshold = strengthToThreshold(safeStrength)
        mutable.update { it.copy(limiterEnabled = enabled, limiterStrength = safeStrength, limiterThreshold = threshold) }
        preferences?.let { stored ->
            viewModelScope.launch { stored.setLimiter(enabled, safeStrength) }
        }
        pushLimiter()
    }
    fun observeNativeRecovery(snapshot: JSONObject, pageUrl: String?) {
        val s = mutable.value
        val document = snapshot.optString("documentId")
        if (!snapshot.optBoolean("ready") || document.isBlank() || document in retiredDocuments) return
        if (currentDocument != null && currentDocument != document) return
        if (pageUrl?.startsWith("https://www.tiktok.com/") != true) return
        val hasLiveTarget = StreamNameNormalizer.liveUrl(s.streamName) != null && currentWebUrl.contains("/live")
        if (!hasLiveTarget || !playerRecoveryRequested || s.vlcReplacementUrl != null || s.forceInProgress || snapshot.optBoolean("pausedByUser") || snapshot.optBoolean("awaitingGesture") || snapshot.optBoolean("vlcActive")) {
            nativePlayerStalledAt = 0L
            nativePlayerTime = null
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (nativePlayerDocument != document || nativePlayerStalledAt == 0L) {
            nativePlayerDocument = document
            nativePlayerStalledAt = now
            nativePlayerTime = null
        }
        val time = snapshot.optDouble("currentTime", Double.NaN).takeIf { it.isFinite() }
        val previous = nativePlayerTime
        nativePlayerTime = time
        if (time != null && previous != null && time > previous + 0.001) {
            nativePlayerStalledAt = now
            nativePlayerAttempt = 0
            return
        }
        val needsPage = !snapshot.optBoolean("videoPresent") || snapshot.optBoolean("ended")
        val waitMs = s.autoReconnectDelaySeconds * 1000L + if (needsPage) 0L else 10_000L
        if (now - nativePlayerStalledAt < waitMs) return
        nativePlayerStalledAt = now
        nativePlayerAttempt++
        mutable.update { it.copy(playerRecovery = mapOf("phase" to "reloading", "reason" to if (needsPage) "video-unavailable" else "player-stall", "attempt" to nativePlayerAttempt, "configuredDelayMs" to s.autoReconnectDelaySeconds * 1000L)) }
        // Use the same native WebView reload as the working manual action, without changing Hook On/Off.
        val onLivePage = pageUrl.contains("/live")
        if (onLivePage) reloadWebPage(enableConnection = false)
        else loadUrl?.invoke(currentWebUrl)
    }

    fun recoveryConfiguration(): Map<String, Any?> = mutable.value.let { state -> mapOf(
        "connection" to connectionRequested,
        "hook" to hookReconnectRequested,
        "hookSeconds" to state.hookReconnectDelaySeconds,
        "player" to playerRecoveryRequested,
        "playerSeconds" to state.autoReconnectDelaySeconds,
        "vlc" to (state.vlcReplacementUrl != null)
    ) }

    private fun pushRecovery() {
        if (!bridgeReady) return
        val s = mutable.value
        sendCommand?.invoke("set-hook-reconnect", mapOf("enabled" to hookReconnectRequested, "delaySeconds" to s.hookReconnectDelaySeconds))
        sendCommand?.invoke("set-auto-reconnect", mapOf("enabled" to playerRecoveryRequested, "delaySeconds" to s.autoReconnectDelaySeconds))
        sendCommand?.invoke("set-vlc-active", mapOf("active" to (s.vlcReplacementUrl != null)))
    }
    fun setHookReconnect(enabled: Boolean) {
        hookReconnectRequested = enabled; pushRecovery()
        preferences?.let { viewModelScope.launch { it.setHookEnabled(enabled) } }
    }
    fun setHookReconnectDelay(seconds: Int) {
        val safe = seconds.coerceIn(1, 59)
        mutable.update { it.copy(hookReconnectDelaySeconds = safe) }; pushRecovery()
        preferences?.let { viewModelScope.launch { it.setHookDelay(safe) } }
    }
    fun openEmbed() {
        if (mutable.value.embedMode && mutable.value.embedPhase in setOf("loading", "retry-wait", "playing", "awaiting-gesture")) return
        val live = StreamNameNormalizer.liveUrl(mutable.value.streamName) ?: currentWebUrl
        val handle = Regex("/@([^/]+)/live").find(live)?.groupValues?.get(1) ?: return
        embedJob?.cancel(); embedStartedAt = System.currentTimeMillis(); embedId = java.util.UUID.randomUUID().toString()
        mutable.update { it.copy(embedMode = true, embedPhase = "loading", embedAttempt = 0, vlcReplacementUrl = null) }
        startEmbedAttempt("https://www.tiktok.com/embed/live/@$handle")
    }
    private fun startEmbedAttempt(url: String) {
        if (!mutable.value.embedMode || mutable.value.embedAttempt >= 3 || System.currentTimeMillis() - embedStartedAt >= 90_000) {
            mutable.update { it.copy(embedPhase = "failed") }; return
        }
        mutable.update { it.copy(embedAttempt = it.embedAttempt + 1, embedPhase = "loading") }
        noteNavigation(url); loadUrl?.invoke(url)
        embedJob = viewModelScope.launch {
            delay(30_000)
            if (mutable.value.embedMode && mutable.value.embedPhase == "loading") startEmbedAttempt(url)
        }
    }
    fun openNormal() {
        if (mutable.value.vlcReplacementUrl != null) toggleVlcReplacement()
        if (!mutable.value.embedMode) return
        embedJob?.cancel(); mutable.update { it.copy(embedMode = false, embedPhase = "cancelled") }
        noteNavigation(currentWebUrl); loadUrl?.invoke(currentWebUrl)
    }
    fun setAutoReconnect(enabled: Boolean) {
        playerRecoveryRequested = enabled
        preferences?.let { stored -> viewModelScope.launch { stored.setAutoReconnect(enabled) } }
        sendCommand?.invoke("set-auto-reconnect", mapOf("enabled" to enabled, "delaySeconds" to mutable.value.autoReconnectDelaySeconds))
    }
    fun setAutoReconnectDelay(seconds: Int) {
        val safe = seconds.coerceIn(1, 59)
        mutable.update { it.copy(autoReconnectDelaySeconds = safe) }
        preferences?.let { stored -> viewModelScope.launch { stored.setAutoReconnectDelay(safe) } }
        sendCommand?.invoke("set-auto-reconnect", mapOf("enabled" to playerRecoveryRequested, "delaySeconds" to safe))
    }
    fun startRecommendationScan(limit: Int) {
        val safe = limit.coerceIn(1, 300)
        mutable.update { it.copy(recommendationStatus = "running", recommendationLimit = safe, recommendationScanned = 0, recommendationItems = emptyList()) }
        sendCommand?.invoke("scan-recommendations", mapOf("limit" to safe))
    }
    fun cancelRecommendationScan() { sendCommand?.invoke("cancel-recommendation-scan", emptyMap()) }
    fun captionJsonLines(): String = mutable.value.captionRecords.joinToString("\n") { it.rawJson }
    fun captionRawJson(): String = JSONArray(mutable.value.captionRecords.map { JSONObject(it.rawJson) }).toString(2)
    fun setLiveLogsEnabled(enabled: Boolean) = mutable.update { it.copy(liveLogsEnabled = enabled) }
    fun clearCaptions() = mutable.update { it.copy(captionRecords = emptyList()) }
    fun setTtsEnabled(enabled: Boolean) { mutable.update { it.copy(ttsEnabled = enabled, speechQueue = if (enabled) it.speechQueue else emptyList()) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsEnabled(enabled) } } }
    fun setTtsVolume(volume: Int) { val value = volume.coerceIn(0, 100); mutable.update { it.copy(ttsVolume = value) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsVolume(value) } } }
    fun setTtsLanguage(language: TtsLanguage) { mutable.update { it.copy(ttsLanguage = language) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsLanguage(language) } } }
    fun setTtsSpeakNames(enabled: Boolean) { mutable.update { it.copy(ttsSpeakNames = enabled) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsSpeakNames(enabled) } } }
    fun setTtsShortenNames(enabled: Boolean) { mutable.update { it.copy(ttsShortenNames = enabled) }; preferences?.let { stored -> viewModelScope.launch { stored.setTtsShortenNames(enabled) } } }
    fun requestSpeak(line: ChatLine) = enqueueSpeech(line)
    fun consumeSpeech(id: Long) = mutable.update { it.copy(speechQueue = it.speechQueue.filterNot { request -> request.id == id }) }
    fun spokenLineAllowed(line: String, now: Long = System.currentTimeMillis()): Boolean {
        val normalized = line.lowercase().replace(Regex("\\s+"), " ").trim()
        if (normalized.isEmpty()) return false
        val iterator = recentSpeech.iterator()
        while (iterator.hasNext()) {
            if (now - iterator.next().value > repeatWindowMs) iterator.remove()
        }
        val last = recentSpeech[normalized]
        recentSpeech[normalized] = now
        return last == null || now - last > repeatWindowMs
    }
    private fun enqueueSpeech(line: ChatLine) {
        val current = mutable.value
        if (ExternalSpeechTriggers.matches(line.content, current.filterExternalSpeechTriggers, current.externalSpeechTriggerCharacters)) return
        val author = if (current.ttsShortenNames) line.author.take(24) else line.author
        val content = if (current.gameModeEnabled) line.content.replace(Regex("\\b[A-ZÄÖÜ]{3}\\b"), "").replace(Regex("\\s+"), " ").trim() else line.content
        val spoken = if (current.ttsSpeakNames && author.isNotBlank()) "$author sagt $content" else content
        val languageTag = current.ttsLanguage.tag ?: when (line.language.lowercase()) { "de", "de-de" -> "de-DE"; "en", "en-us", "en-gb" -> "en-US"; else -> null }
        val request = SpeechRequest(++speechSequence, spoken.take(1_000), languageTag)
        mutable.update { it.copy(speechQueue = (it.speechQueue + request).takeLast(5)) }
    }
    private fun pushLimiter() {
        startupLimiterPending = false
        val current = mutable.value
        sendCommand?.invoke("set-limiter", mapOf("enabled" to current.limiterEnabled, "strength" to current.limiterStrength))
    }
    fun recognize() {
        mutable.update { it.copy(result = null, error = null, recognitionStatus = "Erkennung läuft · maximal 12 Sekunden") }
        if (mutable.value.source == RecognitionSource.MICROPHONE) recognizer.recognizeMicrophone()
        else { recognizer.startPcmStream(); sendCommand?.invoke("start-webview-audio", emptyMap()) }
    }

    fun handle(envelope: BridgeEnvelope) {
        serviceClient?.let { client ->
            client.pairingCode = mutable.value.pairingCode
            client.universalKey = mutable.value.universalCaptionApiKey
            client.auddToken = mutable.value.auddToken
            val recordLiveLogs = mutable.value.liveLogsEnabled
            viewModelScope.launch { runCatching { client.capture(envelope, liveLogsEnabled = recordLiveLogs) }.onFailure { error -> reportError(error.message ?: "Pipeline-Verbindung unterbrochen") } }
        }
        if (connectionPaused && envelope.type in setOf("chat", "caption", "live-stats", "gift", "socket-open")) return
        val doc = envelope.payload["documentId"] as? String
        if (envelope.payload["frameKind"] != "sub" && doc != null) {
            if (doc in retiredDocuments) return
            if (currentDocument == null) currentDocument = doc
            if (doc != currentDocument) return
        }
        mutable.update {
            val events = if (it.debugEnabled) (it.debugEvents + RecoveryDiagnostics.event(envelope)).takeLast(2000) else it.debugEvents
            it.copy(debugEvents = events)
        }
        when (envelope.type) {
            "recovery-ready" -> pushRecovery()
            "hook-status" -> mutable.update { it.copy(
                hookAvailable = envelope.payload["installed"] == true,
                connectionEnabled = connectionRequested && !connectionPaused && envelope.payload["installed"] == true && envelope.payload["armed"] == true,
                connected = !connectionPaused && envelope.payload["connected"] == true
            ) }
            "hook-recovery" -> mutable.update { it.copy(hookRecovery = RecoveryDiagnostics.hook(envelope.payload), hookReconnectEnabled = envelope.payload["enabled"] == true) }
            "player-recovery" -> {
                mutable.update { it.copy(playerRecovery = RecoveryDiagnostics.project(envelope.payload)) }
                if (mutable.value.embedMode && envelope.payload["phase"] == "awaiting-gesture") {
                    embedJob?.cancel(); mutable.update { it.copy(embedPhase = "awaiting-gesture") }
                }
            }
            "caption-state" -> {
                val safe = RecoveryDiagnostics.project(envelope.payload)
                mutable.update { it.copy(captionSources = safe, captionsAvailable = listOf("websocket", "dom", "playerText").any { key -> safe[key] == true }) }
            }
            "embed-blocked" -> if (mutable.value.embedMode) {
                embedJob?.cancel()
                mutable.update { it.copy(embedPhase = if (envelope.payload["reason"] == "ended") "ended" else "login-required") }
            }
            "player-observation" -> if (envelope.payload["playing"] == true) {
                if (startupLimiterPending && mutable.value.vlcReplacementUrl == null) pushLimiter()
                if (mutable.value.embedMode && mutable.value.embedPhase in setOf("loading", "awaiting-gesture")) {
                    embedJob?.cancel(); mutable.update { it.copy(embedPhase = "playing") }
                }
            }
            "bridge-ready" -> {
                bridgeReady = true
                sendCommand?.invoke("set-connection", mapOf("enabled" to connectionRequested))
                sendCommand?.invoke("set-pipeline-enabled", mapOf("enabled" to mutable.value.universalCaptionApiKey.isNotBlank()))
                pushRecovery()
                // Restore protection only after this document reports actual playback.
                startupLimiterPending = true
                sendCommand?.invoke("set-player-expanded", mapOf("expanded" to mutable.value.videoExpanded))
                if (mutable.value.audibleStartRequested) sendCommand?.invoke("start-audible", emptyMap())
            }
            "capability" -> {
                val feature = envelope.payload["feature"] as? String
                val available = envelope.payload["available"] as? Boolean ?: false
                if (feature == "connection") { connectionPaused = !available; mutable.update { it.copy(connectionEnabled = available && connectionRequested && it.hookAvailable, connected = available && it.connected) } }
                if (feature == "player-recovery") mutable.update { it.copy(autoReconnectEnabled = available && envelope.payload["enabled"] == true) }
                if (feature == "websocket-hook") mutable.update { it.copy(hookAvailable = available || it.hookAvailable) }
                if (feature == "webview-audio" && !available && mutable.value.source == RecognitionSource.WEBVIEW) {
                    recognizer.cancel(); mutable.update { it.copy(recognitionStatus = "WebView-Audio nicht verfügbar · Mikrofon wählen") }
                }
                if (feature == "limiter" && mutable.value.vlcReplacementUrl == null) mutable.update { it.copy(
                    limiterEnabled = available && envelope.payload["enabled"] == true,
                    error = if (!available) "Pegelschutz nicht verfügbar · Player oder AudioWorklet fehlt" else it.error
                ) }
            }
            "inspection" -> {
                val info = buildMap {
                    (envelope.payload["title"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Titel", it) }
                    (envelope.payload["url"] as? String)?.takeIf { it.isNotBlank() }?.let { put("URL", it) }
                    (envelope.payload["description"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Beschreibung", it) }
                    (envelope.payload["creatorName"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Creator", it) }
                    (envelope.payload["creatorHandle"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Handle", it) }
                    (envelope.payload["followerText"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Follower", it) }
                    (envelope.payload["followingText"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Gefolgt", it) }
                    (envelope.payload["profileLikesText"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Profil-Likes", it) }
                    (envelope.payload["signature"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Bio", it) }
                    (envelope.payload["language"] as? String)?.takeIf { it.isNotBlank() }?.let { put("Seitensprache", it) }
                    put("Verifiziert", if (envelope.payload["verified"] as? Boolean == true) "ja" else "nein")
                    put("Video vorhanden", if (envelope.payload["videoPresent"] as? Boolean == true) "ja" else "nein")
                    put("Untertitel-Steuerung", if (envelope.payload["captionsControlPresent"] as? Boolean == true) "ja" else "nein")
                }
                mutable.update { it.copy(captionSources = it.captionSources + ("menuAvailable" to (envelope.payload["captionsControlPresent"] == true)), pageInfo = info) }
            }
            "chat" -> {
                val author = envelope.payload["nickname"] as? String ?: ""
                val content = envelope.payload["content"] as? String ?: ""
                val language = envelope.payload["language"] as? String ?: ""
                if (author in mutable.value.mutedAuthors) return
                val entry = ChatLine(author.take(128), content.take(1_000), language.take(24))
                val line = entry.visibleText
                mutable.update { current ->
                    val people = LinkedHashMap(current.participants)
                    if (author.isNotBlank()) {
                        val prior = people[author] ?: ParticipantStats()
                        people[author] = prior.copy(messages = prior.messages + 1, words = prior.words + content.trim().split(Regex("\\s+")).count { it.isNotBlank() })
                    }
                    current.copy(chats = (current.chats + line).takeLast(50), chatEntries = (current.chatEntries + entry).takeLast(50), participants = people)
                }
                if (mutable.value.ttsEnabled) enqueueSpeech(entry)
            }
            "caption" -> {
                val contents = envelope.payload["contents"] as? List<*>
                val first = contents?.firstOrNull() as? Map<*, *>
                val language = (first?.get("lang") ?: envelope.payload["language"] ?: "").toString().take(24)
                val value = (first?.get("text") ?: envelope.payload["text"] ?: "").toString().take(4_000)
                val raw = JSONObject(mapOf("timestamp" to envelope.timestamp, "streamId" to envelope.streamId, "sentenceId" to (envelope.payload["sentenceId"] ?: ""), "definite" to (envelope.payload["definite"] ?: false), "language" to language, "text" to value, "source" to ((envelope.payload["source"] as? String)?.takeIf { it in setOf("websocket", "dom", "playerText") } ?: "websocket"))).toString()
                mutable.update { it.copy(captionsAvailable = true, captionRecords = if (it.liveLogsEnabled) (it.captionRecords + CaptionRecord(envelope.timestamp, (envelope.payload["sentenceId"] ?: "").toString().take(64), envelope.payload["definite"] as? Boolean ?: false, language, value, raw)).takeLast(2000) else it.captionRecords) }
                captionExpiry?.cancel()
                captionExpiry = viewModelScope.launch { delay(15_000); mutable.update { it.copy(captionsAvailable = false) } }
            }
            "recommendation-scan-progress" -> {
                val items = (envelope.payload["items"] as? List<*>)?.mapNotNull { raw ->
                    val item = raw as? Map<*, *> ?: return@mapNotNull null
                    val url = item["url"]?.toString()?.takeIf { BridgeValidator.safeHttpsUrl(it) != null } ?: return@mapNotNull null
                    RecommendationItem(item["handle"]?.toString()?.take(128) ?: return@mapNotNull null, item["displayName"]?.toString()?.take(160) ?: "", item["title"]?.toString()?.take(300) ?: "", (item["viewerCount"] as? Number)?.toLong(), item["viewerLabel"]?.toString()?.take(32) ?: "", url, (item["position"] as? Number)?.toInt() ?: 0)
                } ?: emptyList()
                mutable.update { it.copy(recommendationStatus = envelope.payload["status"]?.toString()?.take(20) ?: "running", recommendationScanned = (envelope.payload["scanned"] as? Number)?.toInt() ?: items.size, recommendationItems = items.distinctBy { item -> item.handle.lowercase() }.take(300)) }
            }
            "live-stats" -> mutable.update { current ->
                val numbers = current.liveNumbers.toMutableMap()
                val mapped = buildMap<String, String> {
                    for ((key, label) in liveStatLabels) {
                        val value = envelope.payload[key] ?: continue
                        val number = value.toString().toDoubleOrNull()?.toLong()
                        if (number != null) {
                            val effective = if (key == "viewerCount") number else maxOf(number, numbers[key] ?: 0)
                            numbers[key] = effective
                            put(label, effective.toString())
                        }
                    }
                    if ((envelope.payload["kind"] as? String) == "follow") put("Follows seit Hook", ((current.liveValues["Follows seit Hook"]?.toIntOrNull() ?: 0) + 1).toString())
                }
                current.copy(liveValues = current.liveValues + mapped, liveNumbers = numbers)
            }
            "audio-chunk" -> {
                val encoded = envelope.payload["data"] as? String ?: return
                val sampleRate = (envelope.payload["sampleRate"] as? Number)?.toInt() ?: 48_000
                runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrNull()?.let { recognizer.appendPcm16(it, sampleRate) }
            }
            "audio-complete" -> recognizer.finishPcmStream()
            "force-return" -> {
                val ok = envelope.payload["ok"] as? Boolean
                if (ok == true) { forceWatchdog?.cancel(); mutable.update { it.copy(forceInProgress = false, forceRecoveryUrl = null) } }
                if (ok == false) recoverForce("Bridge-Rückkehr fehlgeschlagen")
            }
            "force-start" -> mutable.update { it.copy(forceInProgress = true, forceRecoveryUrl = (envelope.payload["url"] as? String) ?: it.forceRecoveryUrl) }
            "limiter" -> {
                if (mutable.value.vlcReplacementUrl == null && mutable.value.limiterEnabled) {
                    val input = (envelope.payload["inputPeakDbfs"] as? Number)?.toDouble()
                    val output = (envelope.payload["outputPeakDbfs"] as? Number)?.toDouble()
                    val reduction = (envelope.payload["reductionDb"] as? Number)?.toDouble()
                    if (input != null && output != null && reduction != null && input.isFinite() && output.isFinite() && reduction.isFinite()) {
                        val mode = if (envelope.payload["limiterMode"] == "Kompressor") "Kompressor" else "Lookahead"
                        mutable.update { it.copy(webLimiterStatus = String.format(java.util.Locale.ROOT,
                            "WebView · %s · Eingang %.1f dBFS · Ausgang %.1f dBFS · Dämpfung %.1f dB", mode, input, output, reduction)) }
                    }
                }
            }
            "quick-recover" -> mutable.update { it.copy(liveValues = it.liveValues + ("Auto-Reconnect" to "aktiv")) }
            "player-state" -> {
                mutable.update { it.copy(playerMuted = envelope.payload["muted"] as? Boolean, audibleStartBlocked = envelope.payload["reason"] == "autoplay-blocked") }
                if (mutable.value.embedMode && envelope.payload["reason"] == "autoplay-blocked") {
                    embedJob?.cancel(); mutable.update { it.copy(embedPhase = "awaiting-gesture") }
                }
            }
            "media-url" -> {
                val safe = BridgeValidator.safeHttpsUrl(envelope.payload["url"] as? String)?.toString() ?: return
                if (!isVlcMediaUrl(safe)) return
                val kind = (envelope.payload["kind"] as? String)?.take(24) ?: "media"
                mutable.update { current ->
                    val next = (current.mediaUrls.filterNot { it.url == safe } + StreamMediaUrl(safe, kind)).takeLast(12)
                    current.copy(mediaUrls = next, vlcReplacementUrl = current.vlcReplacementUrl)
                }
            }
            "command-result" -> if (envelope.payload["ok"] == false) {
                reportError("${envelope.payload["command"]}: ${envelope.payload["error"] ?: "Befehl fehlgeschlagen"}")
            }
            "bridge-error" -> mutable.update { it.copy(error = envelope.payload["message"] as? String ?: "WebView-Bridge-Fehler") }
        }
        if (envelope.type == "chat") serviceClient?.let { client ->
            val people = mutable.value.participants.mapValues { (_, person) -> mapOf("messages" to person.messages, "words" to person.words) }
            viewModelScope.launch { runCatching { client.publishData("top-chatters", people, doc ?: "unknown") } }
        }
    }

    override fun onCleared() { embedJob?.cancel(); captionExpiry?.cancel(); forceWatchdog?.cancel(); recognizer.cancel(); super.onCleared() }

    private fun isVlcMediaUrl(value: String): Boolean = try {
        val uri = java.net.URI(value)
        val host = uri.host?.lowercase() ?: return false
        val allowed = listOf(".tiktokcdn.com", ".tiktokcdn-eu.com", ".tiktokcdn-us.com", ".tiktokcdn-in.com", ".ttlivecdn.com", "cdn.example")
            .any { host == it.removePrefix(".") || host.endsWith(it) }
        val media = "${uri.path.orEmpty()}?${uri.query.orEmpty()}".lowercase()
        uri.scheme == "https" && allowed && (media.contains(".flv") || media.contains(".m3u8") || media.contains("only_audio=1"))
    } catch (_: Exception) { false }

    private fun bestMediaUrl(items: List<StreamMediaUrl>): StreamMediaUrl? =
        items.firstOrNull { it.url.contains(".m3u8", ignoreCase = true) }
            ?: items.firstOrNull { !it.url.contains("only_audio=1", ignoreCase = true) }

    private fun strengthToThreshold(strength: Int): Int = (-4 - (strength.coerceIn(0, 100) * 26 / 100)).coerceIn(-30, -1)
    private fun thresholdToStrength(threshold: Int): Int = (((-threshold.coerceIn(-30, -1) - 4) * 100) / 26).coerceIn(0, 100)
}
