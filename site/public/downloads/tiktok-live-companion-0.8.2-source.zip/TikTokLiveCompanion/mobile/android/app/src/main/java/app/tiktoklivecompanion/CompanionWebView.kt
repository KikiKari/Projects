package app.tiktoklivecompanion

import android.content.Context
import android.content.Intent
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.webkit.WebChromeClient
import android.webkit.CookieManager
import android.os.Message
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.annotation.RawRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import kotlin.math.abs

private fun Context.raw(@RawRes id: Int) = resources.openRawResource(id).bufferedReader().use { it.readText() }

/**
 * FrameLayout, das kurze Taps erkennt, ohne Touch-Events zu konsumieren:
 * Scrollen, Long-Press und Interaktion im WebView bleiben vollständig erhalten.
 */
private class TapDetectingFrameLayout(context: Context, private val onTap: () -> Unit) : FrameLayout(context) {
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val tapTimeout = ViewConfiguration.getTapTimeout().toLong() + 100L
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var candidate = false

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; downTime = event.eventTime; candidate = event.pointerCount == 1 }
            MotionEvent.ACTION_POINTER_DOWN -> candidate = false
            MotionEvent.ACTION_MOVE -> if (abs(event.x - downX) > slop || abs(event.y - downY) > slop) candidate = false
            MotionEvent.ACTION_UP -> if (candidate && event.eventTime - downTime <= tapTimeout) onTap()
            MotionEvent.ACTION_CANCEL -> candidate = false
        }
        return false // Events nie abfangen, nur beobachten
    }
}

private class RecoveryWebView(context: Context) : WebView(context) {
    var navigationGeneration = 0
    var pageLoaded = false
    private var disposed = false
    private var monitor: Runnable? = null

    fun monitorRecovery(script: () -> String, observed: (JSONObject) -> Unit = {}) {
        val task = object : Runnable {
            private var pendingAt = 0L
            override fun run() {
                if (disposed) return
                val now = android.os.SystemClock.elapsedRealtime()
                if (pageLoaded && (pendingAt == 0L || now - pendingAt >= 5_000L)) {
                    val generation = navigationGeneration
                    val ticket = now
                    pendingAt = ticket
                    evaluateJavascript(script()) { result ->
                        if (pendingAt != ticket) return@evaluateJavascript
                        pendingAt = 0L
                        if (!disposed && pageLoaded && generation == navigationGeneration) {
                            runCatching { JSONObject(result) }.getOrNull()?.let(observed)
                        }
                    }
                }
                postDelayed(this, 1_000L)
            }
        }
        monitor = task
        post(task)
    }
    fun disposeRecovery() {
        disposed = true
        monitor?.let { removeCallbacks(it) }
        stopLoading()
        destroy()
    }
}

@Composable fun CompanionWebView(viewModel: CompanionViewModel, modifier: Modifier = Modifier, onTap: () -> Unit = {}) {
    AndroidView(modifier = modifier, factory = { context ->
        val webView = RecoveryWebView(context).apply {
            val bridgeSource = listOf(R.raw.content_core, R.raw.proto_main, R.raw.hook_recovery, R.raw.export_privacy, R.raw.android_recovery, R.raw.recovery_hook, R.raw.webview_bridge).joinToString("\n") { context.raw(it) }
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Desktop-Layout erzwingen: Die mobile TikTok-Seite öffnet den Webcast-WebSocket nicht zuverlässig (0PE-52).
            settings.userAgentString = settings.userAgentString.replace("; wv", "").replace(Regex("Android [^;]+; [^)]+\\)"), "Windows NT 10.0; Win64; x64)").replace(Regex("Mobile Safari"), "Safari")
            settings.useWideViewPort = false
            settings.loadWithOverviewMode = false
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
            if (WebViewFeature.isFeatureSupported(WebViewFeature.START_SAFE_BROWSING)) WebViewCompat.startSafeBrowsing(context) {}
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) WebViewCompat.addDocumentStartJavaScript(this, bridgeSource, setOf(BridgeValidator.ALLOWED_ORIGIN))
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                WebViewCompat.addWebMessageListener(this, "tlcBridge", setOf(BridgeValidator.ALLOWED_ORIGIN)) { _, message, sourceOrigin, isMainFrame, _ ->
                    message.data?.let { BridgeValidator.decode(it, sourceOrigin.toString().removeSuffix("/"), isMainFrame) }?.let(viewModel::handle)
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    navigationGeneration++
                    pageLoaded = false
                    url?.let(viewModel::noteNavigation)
                    super.onPageStarted(view, url, favicon)
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    super.onPageFinished(view, url)
                    if (view.url != url) return
                    pageLoaded = true
                    // Older WebViews may lack document-start injection. Do not leave commands as silent no-ops.
                    view.evaluateJavascript("typeof globalThis.TLC_MOBILE_BRIDGE?.command === 'function'") { ready ->
                        if (ready != "true" && view.url == url && url?.startsWith("https://www.tiktok.com/") == true) {
                            view.evaluateJavascript("(function(){if (!globalThis.TLC_MOBILE_BRIDGE) {\n$bridgeSource\n} return typeof globalThis.TLC_MOBILE_BRIDGE?.command === 'function';})()") { installed ->
                                if (installed != "true") viewModel.reportError("WebView-Bridge konnte nicht geladen werden")
                            }
                        }
                    }
                    for (delayMs in listOf(500L, 1_500L, 3_000L)) view.postDelayed({
                        view.evaluateJavascript("globalThis.TLC_MOBILE_BRIDGE?.command('reject-cookies', {})") {
                            CookieManager.getInstance().flush()
                        }
                    }, delayMs)
                }
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (uri.scheme == "https" && uri.host == "www.tiktok.com") return false
                    if (uri.scheme == "https") context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                    val popup = WebView(context)
                    popup.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(child: WebView, request: WebResourceRequest): Boolean {
                            val target = request.url
                            if (target.scheme == "https" && target.host == "www.tiktok.com") view.loadUrl(target.toString())
                            child.destroy()
                            return true
                        }
                    }
                    (resultMsg.obj as? WebView.WebViewTransport)?.webView = popup
                    resultMsg.sendToTarget()
                    return true
                }
            }
            viewModel.sendCommand = { command, payload -> post {
                evaluateJavascript("(function(){const bridge = globalThis.TLC_MOBILE_BRIDGE; if (typeof bridge?.command !== 'function') return false; bridge.command(${JSONObject.quote(command)}, ${JSONObject(payload).toString()}); return true;})()") { dispatched ->
                    if (dispatched != "true") viewModel.reportError("${command}: WebView-Bridge ist nicht bereit")
                }
            } }
            viewModel.loadUrl = { url -> post { loadUrl(url) } }
            viewModel.reloadPage = { post { reload() } }
            val hookSource = listOf(R.raw.proto_main, R.raw.hook_recovery, R.raw.recovery_hook).joinToString("\n") { context.raw(it) }
            val repairBridge = """(function(){
                if (location.origin !== 'https://www.tiktok.com') return;
                if (!globalThis.TLC_MOBILE_RECOVERY) { ${context.raw(R.raw.android_recovery)} }
                if (!globalThis[Symbol.for('tiktok-live-companion.ws-hook')]) { $hookSource }
                if (typeof globalThis.TLC_MOBILE_BRIDGE?.command !== 'function') { ${context.raw(R.raw.webview_bridge)} }
            })()""".trimIndent()
            monitorRecovery(script = {
                val config = JSONObject(viewModel.recoveryConfiguration()).toString()
                """(function(){
                    if (location.origin !== 'https://www.tiktok.com') return {ready:false};
                    const bridge = globalThis.TLC_MOBILE_BRIDGE;
                    if (typeof bridge?.command !== 'function' || !globalThis.TLC_MOBILE_RECOVERY?.snapshot || !globalThis[Symbol.for('tiktok-live-companion.ws-hook')]) return {ready:false};
                    const config = $config;
                    bridge.command('set-connection', {enabled:config.connection});
                    bridge.command('set-hook-reconnect', {enabled:config.hook, delaySeconds:config.hookSeconds});
                    bridge.command('set-auto-reconnect', {enabled:config.player, delaySeconds:config.playerSeconds});
                    bridge.command('set-vlc-active', {active:config.vlc});
                    globalThis.TLC_MOBILE_RECOVERY?.wake?.();
                    return globalThis.TLC_MOBILE_RECOVERY.snapshot();
                })()""".trimIndent()
            }, observed = { snapshot ->
                if (!snapshot.optBoolean("ready") && url?.startsWith("https://www.tiktok.com/") == true) evaluateJavascript(repairBridge, null)
                else viewModel.observeNativeRecovery(snapshot, url)
            })
            loadUrl(viewModel.currentWebUrl)
        }
        TapDetectingFrameLayout(context, onTap).apply { addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) }
    }, onRelease = { holder -> (holder.getChildAt(0) as? RecoveryWebView)?.disposeRecovery() })
}
