# Model card for dmitri (medium)

* Language: ru_RU (Russian, Russia)
* Speakers: 1
* Quality: medium
* Samplerate: 22,050Hz

## Dataset

* URL: https://github.com/OHF-Voice/voice-datasets
* License: CC0

## Training

Finetuned from U.S. English lessac voice (medium quality).
