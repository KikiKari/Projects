package app.tiktoklivecompanion

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale
import android.os.Bundle

private val Accent = Color(0xFFFF1C50)

internal fun mobileVideoHeightDp(screenHeightDp: Int, landscape: Boolean): Int =
    if (!landscape) screenHeightDp / 2 else (screenHeightDp - 160 - 96).coerceIn(0, 220)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val engine = remember { createRecognitionEngine(applicationContext) }
            val model: CompanionViewModel = viewModel(factory = simpleViewModelFactory { CompanionViewModel(engine, CompanionPreferences(applicationContext)) })
            DisposableEffect(model) {
                model.serviceClient = CompanionServiceClient(applicationContext)
                model.backgroundPlaybackChanged = { enabled ->
                    val intent = Intent(applicationContext, BackgroundPlaybackService::class.java).setAction(if (enabled) BackgroundPlaybackService.ACTION_START else BackgroundPlaybackService.ACTION_STOP)
                    if (enabled) ContextCompat.startForegroundService(applicationContext, intent) else applicationContext.startService(intent)
                }
                BackgroundPlaybackService.commandSink = { command -> model.sendCommand?.invoke(command, emptyMap()) }
                onDispose {
                    model.backgroundPlaybackChanged = null
                    BackgroundPlaybackService.commandSink = null
                }
            }
            MaterialTheme(colorScheme = lightColorScheme(primary = Accent, secondary = Accent)) { CompanionIconTheme { CompanionApp(model) } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun CompanionApp(model: CompanionViewModel) {
    val state by model.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(context) { status ->
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) { model.setTtsEnabled(false); model.reportError("Sprachausgabe konnte nicht gestartet werden") }
    } }
    DisposableEffect(tts) { onDispose { tts.shutdown() } }
    val nextSpeech = state.speechQueue.firstOrNull()
    LaunchedEffect(state.ttsEnabled) { if (!state.ttsEnabled) tts.stop() }
    LaunchedEffect(nextSpeech?.id, ttsReady) {
        if (nextSpeech != null && (state.ttsVoice.startsWith("sherpa-") || state.ttsVoice.startsWith("vits-") || state.serviceVoices.any { it.id == state.ttsVoice })) {
            try {
                val client = requireNotNull(model.serviceClient)
                client.pairingCode = state.pairingCode
                val audio = client.request("/v1/tts", org.json.JSONObject().put("text", nextSpeech.text).put("language", nextSpeech.languageTag ?: "auto").put("voiceName", state.ttsVoice))
                val file = java.io.File.createTempFile("sherpa-", ".wav", context.cacheDir)
                try {
                    file.writeBytes(audio)
                    kotlinx.coroutines.suspendCancellableCoroutine<Unit> { continuation ->
                        val player = android.media.MediaPlayer()
                        continuation.invokeOnCancellation { player.release() }
                        player.setOnCompletionListener { player.release(); if (continuation.isActive) continuation.resumeWith(Result.success(Unit)) }
                        player.setOnErrorListener { _, _, _ -> player.release(); if (continuation.isActive) continuation.resumeWith(Result.failure(IllegalStateException("Sherpa-Wiedergabe fehlgeschlagen"))); true }
                        try { player.setDataSource(file.absolutePath); player.prepare(); player.setVolume(state.ttsVolume / 100f, state.ttsVolume / 100f); player.start() }
                        catch (error: Exception) { player.release(); if (continuation.isActive) continuation.resumeWith(Result.failure(error)) }
                    }
                } finally { file.delete() }
            } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
            catch (error: Exception) { model.reportError(error.message ?: "Sherpa nicht erreichbar") }
            model.consumeSpeech(nextSpeech.id)
            return@LaunchedEffect
        }
        if (!ttsReady) return@LaunchedEffect
        nextSpeech?.let { request ->
            request.languageTag?.let { tts.language = Locale.forLanguageTag(it) }
            tts.voices?.find { it.name == state.ttsVoice }?.let { tts.voice = it }
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, state.ttsVolume / 100f) }
            if (tts.speak(request.text, TextToSpeech.QUEUE_ADD, params, "tlc-chat-${request.id}") == TextToSpeech.ERROR) {
                model.setTtsEnabled(false); model.reportError("Sprachausgabe fehlgeschlagen")
            }
            model.consumeSpeech(request.id)
        }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed -> if (allowed) model.recognize() else model.reportError("Mikrofonzugriff wurde abgelehnt") }
    BackHandler(enabled = state.videoExpanded) { model.toggleVideoExpanded() }
    val configuration = LocalConfiguration.current
    val landscape = configuration.screenWidthDp > configuration.screenHeightDp
    val compactLandscape = landscape && configuration.screenHeightDp < 352
    // Querformat: Video kleiner halten, damit Inhalt unter dem Menüband sichtbar und scrollbar bleibt (0PE-56).
    val videoHeight = mobileVideoHeightDp(configuration.screenHeightDp, landscape).dp
    Scaffold(topBar = { if (!state.videoExpanded) TopAppBar(title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.background(Accent, RoundedCornerShape(8.dp)).padding(7.dp)); Spacer(Modifier.width(10.dp)); Text("TikTok LIVE Companion", fontWeight = FontWeight.Bold) } }, actions = { Icon(Icons.Default.Circle, null, tint = Accent, modifier = Modifier.size(9.dp)); Text(" LIVE", fontSize = 12.sp); Spacer(Modifier.width(14.dp)) }) }) { insets ->
        Column(Modifier.padding(insets).fillMaxSize().then(if (compactLandscape && !state.videoExpanded) Modifier.verticalScroll(rememberScrollState()) else Modifier)) {
            if (!state.videoExpanded) StreamNameField(state, model)
            val playerModifier = if (state.videoExpanded) Modifier.fillMaxSize() else Modifier.fillMaxWidth().height(videoHeight)
            Box(playerModifier) {
                CompanionWebView(model, Modifier.fillMaxSize().alpha(if (state.vlcReplacementUrl == null) 1f else 0f), onTap = model::expandVideo)
                state.vlcReplacementUrl?.let { url ->
                    VlcVideoSurface(url, Modifier.fillMaxSize(), state.limiterEnabled, state.limiterStrength) { active, input, output, reduction, error ->
                        model.reportNativeLimiter(url, active, input, output, reduction, error)
                    }
                }
            }
            if (!state.videoExpanded) {
                PrimaryTabRow(selectedTabIndex = state.tab.ordinal) { CompanionTab.entries.forEach { tab -> Tab(selected = state.tab == tab, onClick = { model.selectTab(tab) }, text = { Text(tab.label) }) } }
                val tabModifier = if (compactLandscape) Modifier.fillMaxWidth().heightIn(min = 96.dp).padding(16.dp) else Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)
                Box(tabModifier) {
                    when (state.tab) {
                        CompanionTab.SONG -> SongTab(state, model) {
                            if (state.source == RecognitionSource.MICROPHONE && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO) else model.recognize()
                        }
                        CompanionTab.CHAT -> ChatTab(state, model, ttsReady, if (ttsReady) tts.voices.orEmpty().toList() else emptyList())
                        CompanionTab.LIVE -> LiveTab(state, model)
                        CompanionTab.PLAYER -> PlayerTab(state, model)
                        CompanionTab.MORE -> MoreTab(state, model)
                    }
                }
            }
        }
    }
    state.error?.let { AlertDialog(onDismissRequest = model::clearError, confirmButton = { TextButton(onClick = model::clearError) { Text("OK") } }, title = { Text("Hinweis") }, text = { Text(it) }) }
}

@Composable private fun StreamNameField(state: CompanionUiState, model: CompanionViewModel) {
    OutlinedTextField(
        value = state.streamName,
        onValueChange = model::setStreamName,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).semantics { contentDescription = "Streamname, mit oder ohne At-Zeichen" },
        singleLine = true,
        label = { Text("Streamname (@creator oder creator)") },
        placeholder = { Text("@creator") },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
        keyboardActions = KeyboardActions(onGo = { model.openStream() }),
        trailingIcon = { IconButton(onClick = model::openStream, enabled = state.streamName.isNotBlank()) { Icon(Icons.Default.PlayArrow, "Stream öffnen") } }
    )
}

@Composable private fun SongTab(state: CompanionUiState, model: CompanionViewModel, recognize: () -> Unit) {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Songs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Button(onClick = recognize, shape = CircleShape, modifier = Modifier.align(Alignment.CenterHorizontally).size(116.dp).semantics { contentDescription = "Jetzt erkennen; höchstens zwölf Sekunden" }) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Search, null, modifier = Modifier.size(34.dp)); Text("Jetzt erkennen", fontWeight = FontWeight.Bold) } }
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { RecognitionSource.entries.forEachIndexed { index, source -> SegmentedButton(selected = state.source == source, onClick = { model.selectSource(source) }, shape = SegmentedButtonDefaults.itemShape(index, RecognitionSource.entries.size)) { Text(source.label, maxLines = 1) } } }
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Circle, null, tint = Color(0xFF009B5A), modifier = Modifier.size(10.dp)); Spacer(Modifier.width(8.dp)); Text(state.recognitionStatus, style = MaterialTheme.typography.bodySmall) }
        state.result?.takeIf { it.matched }?.let { result -> ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(result.title, fontWeight = FontWeight.Bold); Text(result.artist, color = Color.Gray); result.songUrl?.let { url -> TextButton(onClick = { BridgeValidator.safeHttpsUrl(url)?.let { safe -> context.startActivity(Intent(Intent.ACTION_VIEW, safe)) } }) { Text("Song öffnen") } } } } }
    }
}

@Composable private fun CapabilityRows(state: CompanionUiState) { ElevatedCard(Modifier.fillMaxWidth()) { Capability("Connection", state.hookAvailable); HorizontalDivider(); Capability("Titel", state.captionsAvailable); HorizontalDivider(); Capability("Verbindung", state.connected) } }
@Composable private fun Capability(label: String, available: Boolean) { Row(Modifier.fillMaxWidth().heightIn(min = 46.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) { Text(label); Spacer(Modifier.weight(1f)); Icon(Icons.Default.Circle, null, tint = if (available) Color(0xFF009B5A) else Color(0xFFD82035), modifier = Modifier.size(11.dp)) } }
@Composable private fun ChatTab(state: CompanionUiState, model: CompanionViewModel, ttsReady: Boolean, systemVoices: List<android.speech.tts.Voice>) {
    var settingsOpen by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Chat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Vorlesen", Modifier.weight(1f)); OutlinedButton(enabled = ttsReady, onClick = { model.setTtsEnabled(!state.ttsEnabled) }) { CompanionIconLabel(if (state.ttsEnabled && ttsReady) "Off" else "On", if (state.ttsEnabled && ttsReady) "off" else "on") } }
            Text("Lautstärke ${state.ttsVolume} %")
            Slider(state.ttsVolume.toFloat(), { model.setTtsVolume(it.toInt()) }, valueRange = 0f..100f)
            OutlinedButton(onClick = { settingsOpen = true }, modifier = Modifier.fillMaxWidth()) { CompanionIconLabel("Erweiterte Einstellungen", "settings") }
        } }
        Text("Chatzeilen ${state.chatEntries.size}")
        if (state.chatEntries.isEmpty()) Text("Noch keine öffentlichen Chatzeilen empfangen.", color = Color.Gray)
        state.chatEntries.takeLast(5).forEach { line -> ElevatedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(line.visibleText, Modifier.weight(1f)); IconButton(onClick = { model.requestSpeak(line) }) { Icon(Icons.Default.VolumeUp, "Vorlesen") } } } }
        Text("Top-Chatter", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (state.topChatters.isEmpty()) Text("Noch keine Personen im Chat beobachtet.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        if (state.topChatters.isNotEmpty()) TextButton(onClick = model::resetTopChatters) { Text("Top-Chatter zurücksetzen") }
        state.topChatters.take(20).forEach { chatter -> ElevatedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(chatter.author); Spacer(Modifier.weight(1f)); Text("${chatter.messages} N · ${chatter.words} W", fontWeight = FontWeight.Bold); IconButton(onClick = { model.muteAuthor(chatter.author) }) { Icon(Icons.Default.VolumeOff, "Stummschalten") } } } }
    }
    if (settingsOpen) SpeechSettingsDialog(state, model, systemVoices) { settingsOpen = false }
}
@Composable private fun SpeechSettingsDialog(state: CompanionUiState, model: CompanionViewModel, systemVoices: List<android.speech.tts.Voice>, close: () -> Unit) {
    var serviceUrl by remember { mutableStateOf(model.serviceClient?.baseUrl ?: "") }
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(onClick = close) { Text("Schließen") } }, title = { Text("Erweiterte Einstellungen") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(state.auddToken, model::setAuddToken, label = { Text("AudD API-Token") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(state.pairingCode, model::setPairingCode, label = { Text("Pairing-Code") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(state.universalCaptionApiKey, model::setUniversalCaptionApiKey, label = { Text("Universal API-Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(serviceUrl, { serviceUrl = it; model.serviceClient?.baseUrl = it }, label = { Text("Alternative Companion-Adresse (lokal zuerst)") }, singleLine = true)
            Text("Sprache", style = MaterialTheme.typography.labelMedium)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) { TtsLanguage.entries.forEachIndexed { index, language -> SegmentedButton(state.ttsLanguage == language, { model.setTtsLanguage(language) }, SegmentedButtonDefaults.itemShape(index, TtsLanguage.entries.size)) { Text(language.label) } } }
            OutlinedTextField(state.ttsVoice, model::setTtsVoice, label = { Text("Stimme") }, singleLine = true)
            OutlinedButton(model::loadServiceVoices) { Text("Sherpa-Stimmen laden") }
            Text(state.serviceStatus)
            TextButton(onClick = { model.setTtsVoice("Systemstandard") }) { Text("Systemstandard") }
            for (voice in systemVoices.sortedBy { it.name }) { TextButton(onClick = { model.setTtsVoice(voice.name) }) { Text("${voice.name} · ${voice.locale.toLanguageTag()}") } }
            state.serviceVoices.groupBy { it.displayGroup }.forEach { (group, voices) ->
                Text(group, style = MaterialTheme.typography.labelMedium)
                voices.forEach { voice ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { model.setTtsVoice(voice.id) }, modifier = Modifier.weight(1f)) { Text("${voice.name} · ${voice.culture} · ${voice.bytes / 1048576} MiB · ${voice.license}") }
                    if (!voice.installed) TextButton(onClick = { model.installServiceVoice(voice.id) }) { Text("Installieren") }
                }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Chatnamen sprechen", Modifier.weight(1f)); CompanionIconSwitch(state.ttsSpeakNames, model::setTtsSpeakNames) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Chatnamen kürzen", Modifier.weight(1f)); CompanionIconSwitch(state.ttsShortenNames, model::setTtsShortenNames) }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CompanionIconSwitch(state.filterExternalSpeechTriggers, model::setFilterExternalSpeechTriggers)
                Text("Trigger filtern (ext. Sprachdienste)", Modifier.weight(1f))
                OutlinedTextField(state.externalSpeechTriggerCharacters, model::setExternalSpeechTriggerCharacters, modifier = Modifier.width(64.dp), singleLine = true, textStyle = androidx.compose.material3.LocalTextStyle.current.copy(fontSize = 12.sp), keyboardOptions = KeyboardOptions(autoCorrectEnabled = false), label = { Text("Zeichen", fontSize = 10.sp) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Auto-Chat Refresh", Modifier.weight(1f)); CompanionIconSwitch(state.autoChatRefreshEnabled, model::setAutoChatRefreshEnabled) }
            OutlinedTextField(state.autoChatRefreshMinutes.toString(), { value -> value.toIntOrNull()?.let(model::setAutoChatRefreshMinutes) }, label = { Text("Auto-Chat-Refresh in min.") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Game-Mode (Spam-, Emoji, usw. Chatfilter)", Modifier.weight(1f)); CompanionIconSwitch(state.gameModeEnabled, model::setGameMode) }
        }
    })
}
@Composable private fun LiveTab(state: CompanionUiState, model: CompanionViewModel) {
    val context = LocalContext.current
    var recommendationLimit by remember(state.recommendationLimit) { mutableStateOf(state.recommendationLimit.toString()) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("LIVE-Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        CapabilityRows(state)
        if (state.liveValues.isEmpty()) Text("Der WebSocket-Hook liefert die Werte nach dem Laden des Streams.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        state.liveValues.toSortedMap().forEach { (key, value) -> ElevatedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp)) { Text(key); Spacer(Modifier.weight(1f)); Text(value, fontWeight = FontWeight.Bold) } } }
        Text("Personen stummschalten", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        val activeAuthors = state.chatEntries.map { it.author }.filter { it.isNotBlank() }.distinct().takeLast(20)
        if (activeAuthors.isEmpty()) Text("Noch keine Personen aus dem LIVE-Chat verfügbar.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        activeAuthors.forEach { author -> ElevatedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(author, Modifier.weight(1f)); TextButton(onClick = { model.muteAuthor(author) }) { Icon(Icons.Default.VolumeOff, null); Spacer(Modifier.width(6.dp)); Text("Stumm") } } } }
        Text("PROFIL-Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (state.pageInfo.isEmpty()) Text("Noch keine Seitenprüfung ausgeführt · „Status“ im Tab Mehr.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        state.pageInfo.forEach { (key, value) -> ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(key, style = MaterialTheme.typography.labelMedium, color = Color.Gray); Text(value, fontWeight = FontWeight.Bold) } } }
        Text("LIVE-Empfehlungen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(recommendationLimit, { recommendationLimit = it.filter(Char::isDigit).take(3) }, label = { Text("Anzahl") }, enabled = state.recommendationStatus != "running", modifier = Modifier.width(130.dp), singleLine = true)
            if (state.recommendationStatus == "running") OutlinedButton(model::cancelRecommendationScan) { Text("Abbrechen") }
            else Button(onClick = { model.startRecommendationScan(recommendationLimit.toIntOrNull() ?: 20) }) { Text("Scannen") }
        }
        Text("Status: ${state.recommendationStatus} · ${state.recommendationScanned} geprüft · ${state.recommendationItems.size} gefunden", style = MaterialTheme.typography.bodySmall)
        state.recommendationItems.take(300).forEach { item -> ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text("@${item.handle}", fontWeight = FontWeight.Bold); Text(item.displayName); Text(item.viewerLabel.ifBlank { item.viewerCount?.toString() ?: "–" }); if (item.title.isNotBlank()) Text(item.title, style = MaterialTheme.typography.bodySmall); TextButton(onClick = { BridgeValidator.safeHttpsUrl(item.url)?.let { context.startActivity(Intent(Intent.ACTION_VIEW, it)) } }) { Text("Stream öffnen") } } } }
    }
}
@Composable private fun PlayerTab(state: CompanionUiState, model: CompanionViewModel) {
    val context = LocalContext.current
    fun copyMedia(label: String, value: String) {
        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label, value))
    }
    fun openExternalVlc() {
        val url = model.bestVlcMediaUrl() ?: return model.reportError("Keine Media-URL verfügbar")
        val vlcIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("org.videolan.vlc")
        if (vlcIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(vlcIntent)
        } else {
            val store = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=org.videolan.vlc"))
            runCatching { context.startActivity(store) }.getOrElse {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=org.videolan.vlc")))
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Player", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        listOf("play" to "Play", "pause" to "Stop", "mute" to "Mute", "unmute" to "Unmute").chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (command, label) -> OutlinedButton(onClick = { model.sendCommand?.invoke(command, emptyMap()) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { CompanionIconLabel(label, when (command) { "pause" -> "stop"; else -> command }) } } } }
        if (state.playerMuted != false || state.audibleStartBlocked) Button(onClick = model::enableStreamSound, modifier = Modifier.fillMaxWidth()) { Text("Ton aktivieren") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Vollbild nativ: Bridge-„fullscreen" greift im mobilen WebView nicht (0PE-54); PiP ist Nicht-Ziel.
            OutlinedButton(onClick = model::toggleVideoExpanded, modifier = Modifier.weight(1f)) { CompanionIconLabel("Vollbild", "fullscreen") }
            OutlinedButton(onClick = { model.sendCommand?.invoke("reload-player", emptyMap()) }, modifier = Modifier.weight(1f)) { CompanionIconLabel("Neu laden", "reset") }
        }
        OutlinedButton(onClick = model::toggleVlcReplacement, enabled = state.mediaUrls.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { CompanionIconLabel("Player", "player") }
        OutlinedButton(onClick = ::openExternalVlc, enabled = state.mediaUrls.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("VLC Player") }
        Text("Pegelschutz", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(if (state.vlcReplacementUrl != null) state.nativeLimiterStatus else if (state.limiterEnabled) state.webLimiterStatus else "WebView · Pegelschutz aus", style = MaterialTheme.typography.bodySmall)
        CompanionIconSwitch(checked = state.limiterEnabled, onCheckedChange = model::setLimiterEnabled, label = "Pegelschutz aktivieren")
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Schutzstärke"); Spacer(Modifier.weight(1f)); Text("${state.limiterStrength}%", fontWeight = FontWeight.Bold) }
        Slider(value = state.limiterStrength.toFloat(), onValueChange = { model.setLimiter(state.limiterEnabled, it.toInt()) }, valueRange = 0f..100f, enabled = state.limiterEnabled)
        Text("dBFS ist ein digitaler Signalpegel, kein am Ohr messbarer dB-SPL-Wert. Der Schutz komprimiert Spitzen oberhalb des Grenzwerts lokal im WebView.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        Text("HAR-Logs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (state.mediaUrls.isEmpty()) Text("Noch keine direkte Media-URL erkannt. Sie erscheint, sobald TikTok den Player lädt.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        state.mediaUrls.forEach { media -> ElevatedCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(media.kind, style = MaterialTheme.typography.labelMedium, color = Color.Gray); Text(media.url, maxLines = 2) }; TextButton(onClick = { copyMedia("TikTok LIVE Media-URL", media.url) }) { Text("Kopieren") } } } }
        if (state.mediaUrls.isNotEmpty()) OutlinedButton(onClick = { copyMedia("TikTok LIVE Media-URLs", state.mediaUrls.joinToString("\n") { it.url }) }, modifier = Modifier.fillMaxWidth()) { Text("Alle kopieren") }
    }
}
@Composable private fun MoreTab(state: CompanionUiState, model: CompanionViewModel) {
    val context = LocalContext.current
    var connectionSettingsOpen by remember { mutableStateOf(false) }
    var hookDelay by remember(state.hookReconnectDelaySeconds) { mutableStateOf(state.hookReconnectDelaySeconds.toString()) }
    var reconnectDelay by remember(state.autoReconnectDelaySeconds) { mutableStateOf(state.autoReconnectDelaySeconds.toString()) }
    var pendingCaptionExport by remember { mutableStateOf("") }
    val exportCaption = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.use { it.write(pendingCaptionExport.toByteArray(Charsets.UTF_8)) }
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Mehr", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        CompanionIconStylePicker()
        Text("Player-Recovery: ${if (!state.autoReconnectEnabled) "aus" else state.playerRecovery["phase"] ?: "aktiv"}", style = MaterialTheme.typography.bodySmall)
        Text("Hook-Reconnect: ${if (!state.hookReconnectEnabled) "aus" else state.hookRecovery["phase"] ?: "aktiv"}", style = MaterialTheme.typography.bodySmall)
        Text("Connection", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(onClick = { model.setConnectionEnabled(!state.connectionEnabled) }) { CompanionIconLabel(if (state.connectionEnabled) "Off" else "On", if (state.connectionEnabled) "off" else "on") }
            OutlinedButton(onClick = model::openNormal) { CompanionIconLabel("Browser", "browser") }
            OutlinedButton(onClick = model::toggleVlcReplacement, enabled = state.mediaUrls.isNotEmpty()) { CompanionIconLabel("Player", "player") }
            IconButton(onClick = { connectionSettingsOpen = true }) { CompanionIconLabel("Connection-Einstellungen", "settings") }
        }
        if (connectionSettingsOpen) AlertDialog(onDismissRequest = { connectionSettingsOpen = false }, title = { Text("Connection-Einstellungen") }, text = { Column {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Player-Recovery", Modifier.weight(1f)); OutlinedTextField(reconnectDelay, { value -> reconnectDelay = value.filter(Char::isDigit).take(2); value.toIntOrNull()?.let(model::setAutoReconnectDelay) }, label = { Text("Sek.") }, singleLine = true, modifier = Modifier.width(88.dp)); CompanionIconSwitch(state.autoReconnectEnabled, model::setAutoReconnect) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Hook-Reconnect", Modifier.weight(1f)); OutlinedTextField(hookDelay, { value -> hookDelay = value.filter(Char::isDigit).take(2); value.toIntOrNull()?.let(model::setHookReconnectDelay) }, label = { Text("Sek.") }, singleLine = true, modifier = Modifier.width(88.dp)); CompanionIconSwitch(state.hookReconnectEnabled, model::setHookReconnect) }
        } }, confirmButton = { TextButton(onClick = { connectionSettingsOpen = false }) { Text("Schließen") } })
        OutlinedButton(onClick = model::openEmbed) { Text("Embed") }
        Text("Embed: ${state.embedPhase} · Versuch ${state.embedAttempt}/3", style = MaterialTheme.typography.bodySmall)
        listOf("inspect" to "Status", "captions" to "Untertitel", "refresh" to "Reset", "open-report" to "Meldung").forEach { (command, label) -> OutlinedButton(onClick = { model.sendCommand?.invoke(command, emptyMap()) }, modifier = Modifier.fillMaxWidth()) { CompanionIconLabel(label, when(command) { "inspect" -> "status"; "refresh" -> "reset"; "open-report" -> "report"; else -> command }) } }
        OutlinedButton(onClick = model::startForce, enabled = !state.forceInProgress, modifier = Modifier.fillMaxWidth()) { Text(if (state.forceInProgress) "Force läuft …" else "Force") }
        state.forceRecoveryUrl?.let { OutlinedButton(onClick = { model.recoverForce() }, modifier = Modifier.fillMaxWidth()) { Text("Manuell zum LIVE-Stream zurück") } }
        Text("Debugmodus", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Validierte Diagnoseereignisse protokollieren", Modifier.weight(1f)); CompanionIconSwitch(state.debugEnabled, model::setDebugEnabled) }
        Text("${state.debugEvents.size} bereinigte Diagnoseereignisse", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        state.debugEvents.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager; val vlcInstalled = runCatching { context.packageManager.getPackageInfo("org.videolan.vlc", 0) }.isSuccess; clipboard.setPrimaryClip(android.content.ClipData.newPlainText("TikTok LIVE Companion Debug", model.debugReport(vlcInstalled))) }, enabled = state.debugEvents.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Debug kopieren") }
            OutlinedButton(onClick = model::clearDebugEvents, enabled = state.debugEvents.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Leeren") }
        }
        Text("LIVE-Logs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("${state.captionRecords.size} RAW-Untertitelereignisse", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pendingCaptionExport = model.captionJsonLines(); exportCaption.launch("tiktok-live-captions.jsonl") }, enabled = state.captionRecords.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("JSON-L-Export") }
            OutlinedButton(onClick = { pendingCaptionExport = model.captionRawJson(); exportCaption.launch("tiktok-live-caption-raw.json") }, enabled = state.captionRecords.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("RAW-JSON-Export") }
        }
        TextButton(onClick = model::clearCaptions, enabled = state.captionRecords.isNotEmpty()) { Text("Caption-Protokoll leeren") }
        Text("Nicht verfügbare WebView-Funktionen werden als Status angezeigt. Eine Meldung wird nie automatisch ausgefüllt oder abgesendet.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}

inline fun <reified T : androidx.lifecycle.ViewModel> simpleViewModelFactory(crossinline create: () -> T) = object : androidx.lifecycle.ViewModelProvider.Factory { override fun <R : androidx.lifecycle.ViewModel> create(modelClass: Class<R>): R = create() as R }
