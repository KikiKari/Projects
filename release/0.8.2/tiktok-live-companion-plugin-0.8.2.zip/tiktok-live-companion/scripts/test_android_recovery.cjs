const {test}=require('node:test'); const assert=require('node:assert/strict'); const vm=require('node:vm'); const fs=require('node:fs'); const path=require('node:path');
const raw=path.resolve(__dirname,'../../mobile/android/app/src/main/res/raw');
function setup(ios=false){let now=10000,plays=0,seq=0;const timers=new Map(), intervals=[];const listeners={}; const events=[];
 const video={clientWidth:100,clientHeight:100,currentTime:1,paused:false,ended:false,readyState:4,dataset:{},addEventListener(n,f){listeners[n]=f},play:async()=>{plays++},textTracks:[]};
 const root={location:{origin:'https://www.tiktok.com',pathname:'/@creator/live'},crypto:{randomUUID:()=>`11111111-1111-1111-1111-${String(++seq).padStart(12,'0')}`},Date:class extends Date{static now(){return now}},document:{scripts:[],body:{innerText:''},querySelectorAll:s=>s==='video'?[video]:[],querySelector:()=>null},tlcBridge:{postMessage:s=>events.push(JSON.parse(s))},addEventListener(n,f){listeners[n]=f},postMessage(m){events.push(m)},setInterval:f=>{intervals.push(f);return intervals.length},clearInterval(){},setTimeout:(f,ms)=>{const id=++seq;timers.set(id,{f,at:now+ms});return id},clearTimeout:id=>timers.delete(id)};
 if(ios){delete root.tlcBridge;root.webkit={messageHandlers:{tlcBridge:{postMessage:m=>events.push(m)}}}}
 root.top=root;vm.runInNewContext(fs.readFileSync(path.join(raw,'android_recovery.js'),'utf8'),root);
 return {dispatch(data){listeners.message({source:vm.runInNewContext("globalThis",root),origin:root.location.origin,data:{source:"tiktok-live-companion",...data}})},root,video,events,timers,get plays(){return plays},tick(ms){now+=ms;for(const f of intervals)f();for(const [id,t]of [...timers])if(t.at<=now){timers.delete(id);t.f()}},api:root.TLC_MOBILE_RECOVERY};}
test('player recovery waits configured interval once and never touches navigation',()=>{const s=setup();s.api.command('set-auto-reconnect',{enabled:true,delaySeconds:3});s.api.recover('stalled');assert.equal(s.timers.size,1);s.tick(2999);assert.equal(s.plays,0);s.tick(1);assert.equal(s.plays,1);assert.equal(s.root.location.pathname,'/@creator/live')});
test('user pause and VLC cancel pending recovery',()=>{for(const cmd of ['pause','set-vlc-active']){const s=setup();s.api.command('set-auto-reconnect',{enabled:true});s.api.recover('stalled');s.api.command(cmd,{active:true});s.tick(4000);assert.equal(s.plays,0)}});
test('media progress cancels attempt without replacing media',()=>{const s=setup();s.api.command('set-auto-reconnect',{enabled:true});s.api.recover('waiting');s.video.currentTime=2;s.tick(3000);assert.equal(s.plays,0)});
test('caption websocket activity expires independently from menu',()=>{const s=setup();s.dispatch({type:"caption",caption:{contents:[{lang:"de",text:"test"}]}});assert.equal(s.events.filter(x=>x.type==="caption-state").at(-1).payload.websocket,true);s.tick(16000);const e=s.events.filter(x=>x.type==='caption-state').at(-1);assert.equal(e.payload.websocket,false);assert.equal(e.payload.activityTtlMs,15000)});
test('Android uses byte-identical browser controller and protocol parser',()=>{for(const [mobile,browser]of [['hook_recovery.js','hook-recovery.js'],['recovery_hook.js','hook.js'],['proto_main.js','proto-main.js']])assert.deepEqual(fs.readFileSync(path.join(raw,mobile)),fs.readFileSync(path.resolve(__dirname,'../browser-extension',browser))) });

test('iOS WebKit bridge receives correlated recovery observations',()=>{const s=setup(true);s.tick(1000);const e=s.events.find(x=>x.type==='player-observation');assert.ok(e);assert.equal(e.payload.frameKind,'top');assert.match(e.payload.documentId,/^[a-f0-9-]{36}$/);s.dispatch({type:'caption',caption:{text:'ios-caption'}});assert.equal(s.events.filter(x=>x.type==='caption').at(-1).payload.text,'ios-caption')});
test('iOS and Android inject identical recovery implementations',()=>{const ios=path.resolve(__dirname,'../../mobile/ios/Resources');for(const [a,b] of [['android_recovery.js','mobile-recovery.js'],['hook_recovery.js','hook-recovery.js'],['recovery_hook.js','recovery-hook.js'],['export_privacy.js','export-privacy.js'],['proto_main.js','proto-main.js'],['content_core.js','content-core.js']])assert.deepEqual(fs.readFileSync(path.join(raw,a)),fs.readFileSync(path.join(ios,b)))});

test('Connection off stops Companion chat delivery, on resumes without touching player',()=>{
 for(const ios of [false,true]) {
  const s=setup(ios);
  s.api.command('set-connection',{enabled:false});
  s.dispatch({type:'chat-message',chatMessage:{content:'hidden from Companion'}});
  assert.equal(s.events.filter(e=>e.type==='chat').length,0);
  s.api.command('set-connection',{enabled:true});
  s.dispatch({type:'chat-message',chatMessage:{content:'visible'}});
  assert.equal(s.events.filter(e=>e.type==='chat').length,1);
  assert.equal(s.plays,0);
 }
});
