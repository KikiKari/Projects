@echo off
call "%~dp0companion-service\Sprachdienst-reparieren.cmd"
